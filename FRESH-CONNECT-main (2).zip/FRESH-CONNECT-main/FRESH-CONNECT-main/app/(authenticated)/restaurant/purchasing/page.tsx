import { DirectPurchasing } from "@/components/restaurant/direct-purchasing"

export default function DirectPurchasingPage() {
  return <DirectPurchasing />
}
