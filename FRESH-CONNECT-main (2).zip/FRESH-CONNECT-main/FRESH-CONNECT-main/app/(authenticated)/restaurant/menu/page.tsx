import { MenuPlanning } from "@/components/restaurant/menu-planning"

export default function MenuPlanningPage() {
  return <MenuPlanning />
}
