import { InventoryTracking } from "@/components/restaurant/inventory-tracking"

export default function InventoryTrackingPage() {
  return <InventoryTracking />
}
