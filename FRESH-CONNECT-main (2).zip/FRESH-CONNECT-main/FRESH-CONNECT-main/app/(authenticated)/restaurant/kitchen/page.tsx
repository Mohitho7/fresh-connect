import { KitchenDashboard } from "@/components/restaurant/kitchen-dashboard"

export default function KitchenDashboardPage() {
  return <KitchenDashboard />
}
