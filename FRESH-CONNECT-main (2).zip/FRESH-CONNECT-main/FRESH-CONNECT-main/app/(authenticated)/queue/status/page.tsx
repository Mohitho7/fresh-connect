import { QueueStatus } from "@/components/queue/queue-status"

export default function QueueStatusPage() {
  return <QueueStatus />
}
