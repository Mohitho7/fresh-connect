import { TokenGenerator } from "@/components/queue/token-generator"

export default function TokenGeneratorPage() {
  return <TokenGenerator />
}
