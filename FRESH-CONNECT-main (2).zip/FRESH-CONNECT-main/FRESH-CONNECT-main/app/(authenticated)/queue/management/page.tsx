import { QueueManagement } from "@/components/queue/queue-management"

export default function QueueManagementPage() {
  return <QueueManagement />
}
