import { OrderHistory } from "@/components/customer/order-history"

export default function OrderHistoryPage() {
  return <OrderHistory />
}
