import { MenuBrowsing } from "@/components/customer/menu-browsing"

export default function MenuBrowsingPage() {
  return <MenuBrowsing />
}
