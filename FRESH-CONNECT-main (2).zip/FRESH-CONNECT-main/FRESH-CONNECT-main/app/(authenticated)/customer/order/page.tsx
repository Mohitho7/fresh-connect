import { FoodOrdering } from "@/components/customer/food-ordering"

export default function FoodOrderingPage() {
  return <FoodOrdering />
}
