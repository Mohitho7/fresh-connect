import { CafeteriaSelection } from "@/components/customer/cafeteria-selection"

export default function CafeteriaSelectionPage() {
  return <CafeteriaSelection />
}
