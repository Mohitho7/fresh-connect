import { SalesDashboard } from "@/components/farmer/sales-dashboard"

export default function SalesDashboardPage() {
  return <SalesDashboard />
}
