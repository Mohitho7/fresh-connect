import { ProduceList } from "@/components/farmer/produce-list"

export default function ProduceListingPage() {
  return <ProduceList />
}
