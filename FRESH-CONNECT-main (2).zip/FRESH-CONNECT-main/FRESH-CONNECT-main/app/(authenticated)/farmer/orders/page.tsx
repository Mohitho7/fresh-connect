import { OrderAlerts } from "@/components/farmer/order-alerts"

export default function OrderAlertsPage() {
  return <OrderAlerts />
}
