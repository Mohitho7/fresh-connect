import { CropCalendar } from "@/components/farmer/crop-calendar"

export default function CropCalendarPage() {
  return <CropCalendar />
}
